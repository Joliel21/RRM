#!/usr/bin/env python3
"""
Build a Patient Voice source archive compatible with the existing
Series Spread workflow.

Output:
    patient-voice.zip
        manifest.csv
        images/*
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import mimetypes
import re
import sys
import time
import zipfile
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Iterable
from urllib.parse import urljoin, urlparse

import requests
from bs4 import BeautifulSoup

CATEGORY_URL = "https://rarerevolutionmagazine.com/category/rare-insights/patient-voice/"
DEFAULT_USER_AGENT = (
    "Mozilla/5.0 (compatible; PatientVoiceArchiveBuilder/1.0; "
    "+https://rarerevolutionmagazine.com/)"
)

@dataclass
class Article:
    title: str
    article_url: str
    published_date: str
    image_url: str
    filename: str = ""
    status: str = ""
    error: str = ""

def clean_text(value: str | None) -> str:
    return re.sub(r"\s+", " ", value or "").strip()

def absolute(base: str, value: str | None) -> str:
    return urljoin(base, value or "")

def same_domain(url: str) -> bool:
    return urlparse(url).netloc.endswith("rarerevolutionmagazine.com")

def normalize_date(value: str) -> str:
    value = clean_text(value)
    if not value:
        return ""
    for fmt in (
        "%Y-%m-%d",
        "%d %B %Y",
        "%B %d, %Y",
        "%d %b %Y",
        "%b %d, %Y",
    ):
        try:
            return datetime.strptime(value, fmt).date().isoformat()
        except ValueError:
            pass
    m = re.search(r"(\d{4})-(\d{2})-(\d{2})", value)
    return m.group(0) if m else value

def get_soup(session: requests.Session, url: str, timeout: int) -> BeautifulSoup:
    response = session.get(url, timeout=timeout)
    response.raise_for_status()
    return BeautifulSoup(response.text, "html.parser")

def discover_category_pages(
    session: requests.Session,
    start_url: str,
    timeout: int,
    max_pages: int | None,
) -> list[str]:
    pages: list[str] = []
    seen: set[str] = set()
    current = start_url

    while current and current not in seen:
        seen.add(current)
        pages.append(current)
        if max_pages and len(pages) >= max_pages:
            break

        soup = get_soup(session, current, timeout)
        next_link = (
            soup.select_one("a.next.page-numbers")
            or soup.select_one("a[rel='next']")
            or soup.find("a", string=re.compile(r"Next", re.I))
        )
        current = absolute(current, next_link.get("href")) if next_link else ""

    return pages

def discover_article_links(soup: BeautifulSoup, page_url: str) -> list[str]:
    links: list[str] = []
    seen: set[str] = set()

    selectors = (
        "article h2 a",
        "article h3 a",
        "article .entry-title a",
        ".post-title a",
        ".elementor-post__title a",
        "main a",
    )

    for selector in selectors:
        for anchor in soup.select(selector):
            href = absolute(page_url, anchor.get("href"))
            text = clean_text(anchor.get_text(" ", strip=True))
            if (
                href
                and href not in seen
                and same_domain(href)
                and "/category/" not in href
                and text
            ):
                seen.add(href)
                links.append(href)

        if links and selector != "main a":
            break

    return links

def parse_article(
    session: requests.Session,
    url: str,
    timeout: int,
) -> Article:
    soup = get_soup(session, url, timeout)

    title = ""
    for selector in (
        "meta[property='og:title']",
        "h1.entry-title",
        "h1",
        "title",
    ):
        node = soup.select_one(selector)
        if not node:
            continue
        title = clean_text(node.get("content") if node.name == "meta" else node.get_text(" ", strip=True))
        if title:
            break

    image_url = ""
    for selector, attr in (
        ("meta[property='og:image']", "content"),
        ("meta[name='twitter:image']", "content"),
        ("article img", "src"),
        ("main img", "src"),
    ):
        node = soup.select_one(selector)
        if node and node.get(attr):
            image_url = absolute(url, node.get(attr))
            break

    date_value = ""
    for selector, attr in (
        ("meta[property='article:published_time']", "content"),
        ("time[datetime]", "datetime"),
        ("meta[name='date']", "content"),
    ):
        node = soup.select_one(selector)
        if node and node.get(attr):
            date_value = node.get(attr, "").split("T")[0]
            break

    if not date_value:
        body_text = clean_text(soup.get_text(" ", strip=True))
        m = re.search(
            r"\b(\d{1,2}\s+(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{4})\b",
            body_text,
            re.I,
        )
        date_value = m.group(1) if m else ""

    return Article(
        title=title,
        article_url=url,
        published_date=normalize_date(date_value),
        image_url=image_url,
    )

def infer_extension(content_type: str, image_url: str) -> str:
    ext = Path(urlparse(image_url).path).suffix.lower()
    if ext in {".jpg", ".jpeg", ".png", ".webp", ".gif"}:
        return ".jpg" if ext == ".jpeg" else ext

    guessed = mimetypes.guess_extension(content_type.split(";")[0].strip()) or ".jpg"
    return ".jpg" if guessed == ".jpe" else guessed

def download_image(
    session: requests.Session,
    article: Article,
    images_dir: Path,
    timeout: int,
) -> None:
    if not article.image_url:
        article.status = "missing_image_url"
        article.error = "No article image URL discovered."
        return

    try:
        response = session.get(article.image_url, timeout=timeout, stream=True)
        response.raise_for_status()
        ext = infer_extension(response.headers.get("content-type", ""), article.image_url)
        digest = hashlib.sha1(article.article_url.encode("utf-8")).hexdigest()[:8]
        filename = f"patient-voice-{digest}{ext}"
        destination = images_dir / filename

        with destination.open("wb") as handle:
            for chunk in response.iter_content(chunk_size=1024 * 64):
                if chunk:
                    handle.write(chunk)

        article.filename = filename
        article.status = "downloaded"
    except Exception as exc:
        article.status = "failed"
        article.error = str(exc)

def unique_articles(items: Iterable[Article]) -> list[Article]:
    output: list[Article] = []
    seen: set[str] = set()
    for article in items:
        if article.article_url not in seen:
            seen.add(article.article_url)
            output.append(article)
    return output

def write_manifest(path: Path, articles: list[Article]) -> None:
    columns = [
        "title",
        "article_url",
        "publication_date",
        "archive_image_url",
        "filename",
        "status",
        "error",
    ]
    with path.open("w", newline="", encoding="utf-8-sig") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        for article in articles:
            writer.writerow(
                {
                    "title": article.title,
                    "article_url": article.article_url,
                    "publication_date": article.published_date,
                    "archive_image_url": article.image_url,
                    "filename": article.filename,
                    "status": article.status,
                    "error": article.error,
                }
            )

def build_zip(source_dir: Path, output_zip: Path) -> None:
    with zipfile.ZipFile(output_zip, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(source_dir.rglob("*")):
            if path.is_file():
                archive.write(path, path.relative_to(source_dir))

def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--url", default=CATEGORY_URL)
    parser.add_argument("--output", default="patient-voice.zip")
    parser.add_argument("--max-pages", type=int, default=None)
    parser.add_argument("--delay", type=float, default=0.4)
    parser.add_argument("--timeout", type=int, default=30)
    args = parser.parse_args()

    output_zip = Path(args.output).resolve()
    build_dir = output_zip.with_suffix("")
    images_dir = build_dir / "images"
    images_dir.mkdir(parents=True, exist_ok=True)

    session = requests.Session()
    session.headers.update({"User-Agent": DEFAULT_USER_AGENT})

    try:
        page_urls = discover_category_pages(
            session, args.url, args.timeout, args.max_pages
        )
    except Exception as exc:
        print(f"Failed to read category pages: {exc}", file=sys.stderr)
        return 1

    article_urls: list[str] = []
    for page_url in page_urls:
        try:
            soup = get_soup(session, page_url, args.timeout)
            article_urls.extend(discover_article_links(soup, page_url))
            time.sleep(args.delay)
        except Exception as exc:
            print(f"Warning: failed to parse {page_url}: {exc}", file=sys.stderr)

    articles: list[Article] = []
    for index, article_url in enumerate(dict.fromkeys(article_urls), start=1):
        print(f"[{index}/{len(dict.fromkeys(article_urls))}] {article_url}")
        try:
            article = parse_article(session, article_url, args.timeout)
            download_image(session, article, images_dir, args.timeout)
        except Exception as exc:
            article = Article(
                title="",
                article_url=article_url,
                published_date="",
                image_url="",
                status="failed",
                error=str(exc),
            )
        articles.append(article)
        time.sleep(args.delay)

    articles = unique_articles(articles)
    write_manifest(build_dir / "manifest.csv", articles)
    build_zip(build_dir, output_zip)

    downloaded = sum(a.status == "downloaded" for a in articles)
    print(f"\nCreated: {output_zip}")
    print(f"Articles found: {len(articles)}")
    print(f"Images downloaded: {downloaded}")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())

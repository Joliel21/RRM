# Patient Voice archive builder

This creates the missing `patient-voice.zip` source archive in the same basic
format used by the other RARE Insights downloads:

```text
patient-voice.zip
├── manifest.csv
└── images/
```

## Run

1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Install the dependencies:

```bash
python -m pip install -r requirements.txt
```

4. Build the archive:

```bash
python build_patient_voice_archive.py
```

The result will be `patient-voice.zip`.

## Optional test run

To process only the first category page:

```bash
python build_patient_voice_archive.py --max-pages 1
```

## Then

Upload the generated `patient-voice.zip` to CodeX and ask:

> Create the Patient Voice Series Spread handoff from this archive using the
> established workflow.

The builder stores the original article URL, publication date, image URL,
downloaded filename, status, and any download error in `manifest.csv`.

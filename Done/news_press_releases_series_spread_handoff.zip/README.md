# News Series Spread Handoff

Prepared for pages 108–109.

- Magazine label: News
- Source category: Press Releases
- Six selected articles and six local images
- Shared Series Spread component required

The original manifest labels every article `RARE News`; display titles in `news.data.json` were therefore derived from the supplied article URL slugs.

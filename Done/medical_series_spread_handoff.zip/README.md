# Medical Series Spread Handoff

This package contains the Medical Series Spread for pages 104–105.

## Files

- `spread-manifest.json` — authoritative package metadata
- `medical.data.json` — six selected article records
- `assets/` — six supplied article images
- `source-manifest.csv` — original archive manifest
- `integration-prompt.txt` — prompt to send with this ZIP

## Important

The six most recent downloaded entries were selected using dates embedded in the supplied archive image URLs.

The source archive did not provide a subtitle, introductory paragraph, category CTA label, or category CTA URL. These fields are intentionally null and must not be invented.

Reuse the magazine’s existing shared Series Spread component.

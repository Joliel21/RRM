# Editors’ Letters Series Spread Handoff

This package contains the complete content handoff for the Editors’ Letters Series Spread.

## Placement

- Left page: 102
- Right page: 103
- Layout: Series Spread

## Files

- `spread-manifest.json` — authoritative package metadata
- `editorsLetters.data.json` — spread content
- `assets/` — six selected article images
- `source-manifest.csv` — original supplied archive manifest
- `integration-prompt.txt` — message to use when attaching this ZIP

## Integration

Copy the six images to:

`public/series/editors-letters/`

Reuse the magazine’s existing shared Series Spread component. Do not replace or duplicate that component unless explicitly required by the project.

The package manifest and data file are authoritative. Chat corrections take priority if supplied before integration.

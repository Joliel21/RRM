# Weblinks & References Series Spread Handoff

Prepared for pages 132–133.

## Files
- `spread-manifest.json`
- `weblinksReferences.data.json`
- `assets/`
- `source-manifest.csv`
- `integration-prompt.txt`

Reuse the existing shared `SeriesSpread` component.
Copy assets to `public/series/weblinks-references/`.

This is the final Series Spread package in the current magazine sequence.

# Spotlight Editions two-page spread handoff

Configured as one continuous two-page scrolling archive spread for pages 204–205.

Copy `assets/` to `public/spotlight-editions/` and use `spotlightEditions.data.json` as the data source. The covers should scroll across the combined two-page area, not render as two separate article regions.

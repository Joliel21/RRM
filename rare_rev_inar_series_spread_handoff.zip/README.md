# Rare Rev-inar Series Spread Handoff

Prepared for pages 122–123.

## Files
- `spread-manifest.json`
- `rareRevInar.data.json`
- `assets/`
- `source-manifest.csv`
- `integration-prompt.txt`

Reuse the existing shared Series Spread component.
Copy assets to `public/series/rare-rev-inar/`.

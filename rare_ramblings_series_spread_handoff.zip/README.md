# Rare Ramblings
Pages 120–121
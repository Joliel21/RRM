# Rare Entrepreneur Series Spread
Pages 134–135

Use the shared `SeriesSpread` component as one continuous two-page spread. Copy all files from `assets/` to `public/series/rare-entrepreneur-series/`.

# Spotlight Editions archive

Contains the Spotlight Editions listed across both website archive pages, ordered newest to oldest.

- `manifest.csv`: edition label, title, date, link, image source, local filename and status.
- `images/`: cover images captured from the supplied HAR.

`url_status=exact` means the exact linked edition URL was present in the supplied page HTML. `content-page` is a verified RARE Revolution content page for that edition. `archive-page` means the supplied HAR did not preserve the individual card link, so the archive page URL is retained rather than inventing a destination.
